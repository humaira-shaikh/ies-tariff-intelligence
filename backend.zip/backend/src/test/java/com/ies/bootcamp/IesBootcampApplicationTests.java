package com.ies.bootcamp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IesBootcampApplicationTests {

	@Test
	void contextLoads() {
	}

}
